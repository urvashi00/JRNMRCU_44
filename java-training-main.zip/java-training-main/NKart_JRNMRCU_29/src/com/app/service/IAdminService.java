package com.app.service;

public interface IAdminService {
//	Login method
	boolean login(String username, String password);
}
